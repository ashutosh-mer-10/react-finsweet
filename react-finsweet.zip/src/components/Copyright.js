import React from "react";

const Copyright = () => {
  return (
    <>
      <div className="copyright-wrap">
        <div className="container">
          <h5 className="h5 copyright ">© Copyright Finsweet 2021</h5>
        </div>
      </div>
    </>
  );
};

export default Copyright;
