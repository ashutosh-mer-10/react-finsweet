import React from "react";
import { Link } from "react-router-dom";
import Recentep from "../components/Recentep";
import BannerImg from "../images/about-banner-img.png";
import InfoIcon from "../images/about-info-icon.png";
import { About_Info_Data } from "../data/logo-data";
// import Few_Words_Img from "../images/";

const About = () => {
  return (
    <>
      <div className="about-banner-wrap banner-padding">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-5">
              <div className="content">
                <h1 className="title">About Finsweet Podcast</h1>
                <p className="info">
                  Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
                  diam nonumy eirmod tempor invidunt ut labore et dolore magna
                  aliquyam erat, sed diam voluptua.
                </p>
                <div className="btn-wrap">
                  <Link to="/" className="cta-btn cta-btn-primary">
                    Subscribe Now
                  </Link>
                </div>
              </div>
            </div>
            <div className="col-lg-7">
              <div className="img-box">
                <img
                  src={BannerImg}
                  alt="banner-img"
                  width={480}
                  height={480}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="page-wrapper">
        <div className="about-info-wrap">
          <div className="container">
            <div className="row">
              {About_Info_Data.map((item, index) => {
                return (
                  <>
                    <div className="col-lg-4">
                      <div className="content">
                        <img
                          src={item.icon}
                          alt="icon"
                          width={80}
                          height={80}
                        />
                        <h4 className="h4 title">{item.title}</h4>
                        <p className="info">{item.info}</p>
                      </div>
                    </div>
                  </>
                );
              })}
            </div>
          </div>
        </div>

        <div className="few-words-wrap">
          <div className="container">
            <div className="inner-wrap">
              <h1 className="h1 title">A few words about our team</h1>
              {/* <img src={Few_Words_Img} alt="" className="img-box" /> */}
            </div>
          </div>
        </div>
        <Recentep />
      </div>
    </>
  );
};

export default About;
